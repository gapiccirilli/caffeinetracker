package com.angelopicc.caffeinetracker.services.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.angelopicc.caffeinetracker.entities.Caffeine;
import com.angelopicc.caffeinetracker.entities.DailyIntake;
import com.angelopicc.caffeinetracker.exceptions.IntakeNotFoundException;
import com.angelopicc.caffeinetracker.payload.DailyIntakeDto;
import com.angelopicc.caffeinetracker.repository.DailyIntakeRepository;
import com.angelopicc.caffeinetracker.services.DailyIntakeService;

@Service
public class StandardDailyIntakeService implements DailyIntakeService {

    private DailyIntakeRepository dailyIntakeRepository;

    public StandardDailyIntakeService(DailyIntakeRepository dailyIntakeRepository) {
        this.dailyIntakeRepository = dailyIntakeRepository;
    }

    @Override
    public DailyIntakeDto getDailyIntake(String tenantId, LocalDate date) {
        
        DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(date, tenantId);

        if (intake == null) {
            throw new IntakeNotFoundException(date);
        }

        return mapToDto(intake);
        
    }

    @Override
    public Set<DailyIntakeDto> getAllIntakes(String tenantId, LocalDate startDate, LocalDate endDate) {

        DailyIntake startIntake = dailyIntakeRepository.findByDateAndTenantId(startDate, tenantId);

        DailyIntake endIntake = dailyIntakeRepository.findByDateAndTenantId(endDate, tenantId);

        List<DailyIntake> intakes = new ArrayList<>();
        
        intakes = dailyIntakeRepository.findByTenantIdAndDateBetween(tenantId, startIntake.getDate(), endIntake.getDate());
        
        
        Set<DailyIntakeDto> intakeDtos = new HashSet<>();

        for (DailyIntake dailyIntake : intakes) {
            DailyIntakeDto dto = new DailyIntakeDto();
            dto.setCaffeineContent(dailyIntake.getCaffeineContent());
            dto.setYear(dailyIntake.getDate().getYear());
            dto.setMonth(dailyIntake.getDate().getMonthValue());
            dto.setDay(dailyIntake.getDate().getDayOfMonth());
            dto.setId(dailyIntake.getId());

            intakeDtos.add(dto);
        }

        return intakeDtos;


    }

    @Override
    public DailyIntake updateDailyIntake(String tenantId, Caffeine caffeine) {

        DailyIntake intake = caffeine.getDailyIntake();


        if (intake != null) {
            int totalCaffeine = 0;

            for (Caffeine caf : intake.getCaffeine()) {
                totalCaffeine += caf.getAmount();
            }
            totalCaffeine += caffeine.getAmount();
            intake.setCaffeineContent(totalCaffeine);
        }
        return intake;
    }

    public void refreshCaffeineAmount(String tenantId, long caffeineId, LocalDate date) {
        DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(date, tenantId);

        Set<Caffeine> caffeineSet = intake.getCaffeine();
        for (Caffeine caf : caffeineSet) {
            if (caf.getId() == caffeineId) {
                caffeineSet.remove(caf);   
            }
        }
        intake.setCaffeine(caffeineSet);

        int totalCaffeine = 0;
        for (Caffeine caf : caffeineSet) {
            totalCaffeine += caf.getAmount();
        }
        intake.setCaffeineContent(totalCaffeine);
        dailyIntakeRepository.save(intake);
    }

    private DailyIntakeDto mapToDto(DailyIntake intake) {
        DailyIntakeDto dto = new DailyIntakeDto();

        dto.setId(intake.getId());
        dto.setYear(intake.getDate().getYear());
        dto.setMonth(intake.getDate().getMonthValue());
        dto.setDay(intake.getDate().getDayOfMonth());
        dto.setCaffeineContent(intake.getCaffeineContent());

        return dto;
    }
}
