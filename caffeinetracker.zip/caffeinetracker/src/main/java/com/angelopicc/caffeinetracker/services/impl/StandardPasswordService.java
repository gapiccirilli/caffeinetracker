package com.angelopicc.caffeinetracker.services.impl;

import com.angelopicc.caffeinetracker.services.PasswordService;

public class StandardPasswordService implements PasswordService {

    @Override
    public void resetPassword(String email) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void forgotPassword(String email) {
        // TODO Auto-generated method stub
        
    }
    
}
