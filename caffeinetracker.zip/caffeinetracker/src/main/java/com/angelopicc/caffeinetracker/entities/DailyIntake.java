package com.angelopicc.caffeinetracker.entities;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "daily_intake")
public class DailyIntake {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String tenantId;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "caffeine_content")
    private int caffeineContent = 0;

    @Column(name = "is_Reduced")
    private boolean isReduced = false;

    @Column(name = "difference")
    private int difference = 0;

    @OneToMany(mappedBy = "dailyIntake", cascade = {CascadeType.REMOVE, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH}, 
    fetch = FetchType.EAGER)
    private Set<Caffeine> caffeine = new HashSet<>();

    public DailyIntake(long id, String tenantId, LocalDate date, int caffeineContent, boolean isReduced, int difference,
            Set<Caffeine> caffeine) {
        this.id = id;
        this.tenantId = tenantId;
        this.date = date;
        this.caffeineContent = caffeineContent;
        this.isReduced = isReduced;
        this.difference = difference;
        this.caffeine = caffeine;
    }

    public DailyIntake() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getCaffeineContent() {
        return caffeineContent;
    }

    public void setCaffeineContent(int caffeineContent) {
        this.caffeineContent = caffeineContent;
    }

    public boolean isReduced() {
        return isReduced;
    }

    public void setReduced(boolean isReduced) {
        this.isReduced = isReduced;
    }

    public int getDifference() {
        return difference;
    }

    public void setDifference(int difference) {
        this.difference = difference;
    }

    public Set<Caffeine> getCaffeine() {
        return caffeine;
    }

    public void setCaffeine(Set<Caffeine> caffeine) {

        this.caffeine = caffeine;
    }

    public void addCaffeine(Caffeine caffeine) {
        this.caffeine.add(caffeine);
    }

    public void addCaffeineContent(int content) {
        this.caffeineContent += content;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    @Override
    public String toString() {
        return "DailyIntake [id=" + id + ", tenantId=" + tenantId + ", date=" + date + ", caffeineContent="
                + caffeineContent + ", isReduced=" + isReduced + ", difference=" + difference + ", caffeine=" + caffeine
                + "]";
    }
}
