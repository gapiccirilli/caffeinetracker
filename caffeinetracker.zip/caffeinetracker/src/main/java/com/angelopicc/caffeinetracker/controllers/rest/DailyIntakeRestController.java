package com.angelopicc.caffeinetracker.controllers.rest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.angelopicc.caffeinetracker.exceptions.IntakeNotFoundException;
import com.angelopicc.caffeinetracker.payload.DailyIntakeDto;
import com.angelopicc.caffeinetracker.payload.DateDto;
import com.angelopicc.caffeinetracker.payload.DateRangeDto;
import com.angelopicc.caffeinetracker.security.filter.TenantIdValidator;
import com.angelopicc.caffeinetracker.services.DailyIntakeService;

@RestController
@RequestMapping("/api")
public class DailyIntakeRestController {

    private DailyIntakeService dailyIntakeService;

    private TenantIdValidator tenantIdValidator;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public DailyIntakeRestController(DailyIntakeService dailyIntakeService, TenantIdValidator tenantIdValidator) {
        this.dailyIntakeService = dailyIntakeService;
        this.tenantIdValidator = tenantIdValidator;
    }

    @GetMapping("/{tenantId}/intake/intakedate")
    public ResponseEntity<DailyIntakeDto> getDailyIntake(@PathVariable String tenantId, @RequestParam String date) {

        tenantIdValidator.tenantIdIsValid(tenantId);

        return new ResponseEntity<>(dailyIntakeService.getDailyIntake(tenantId, LocalDate.parse(date, formatter)), 
        HttpStatus.OK);
    }

    @GetMapping("/{tenantId}/intake")
    public ResponseEntity<Set<DailyIntakeDto>> getAllIntakes(@PathVariable String tenantId, @RequestParam String startDate, 
    @RequestParam String endDate) {

        tenantIdValidator.tenantIdIsValid(tenantId);
        
        return new ResponseEntity<>(dailyIntakeService.getAllIntakes(tenantId, LocalDate.parse(startDate, formatter), 
        LocalDate.parse(endDate, formatter)), HttpStatus.OK);
    }

}
