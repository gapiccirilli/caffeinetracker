package com.angelopicc.caffeinetracker.exceptions;

public class EmailAlreadyExists extends RuntimeException {

    public EmailAlreadyExists(String email) {
        super("The email " + "\"" + email + "\" aleady exists in our records");
    }
    
}
