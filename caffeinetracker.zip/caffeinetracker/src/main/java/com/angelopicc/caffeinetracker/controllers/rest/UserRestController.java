package com.angelopicc.caffeinetracker.controllers.rest;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.angelopicc.caffeinetracker.payload.ConfirmDeleteDto;
import com.angelopicc.caffeinetracker.payload.LoginDto;
import com.angelopicc.caffeinetracker.payload.RegisterDto;
import com.angelopicc.caffeinetracker.payload.UserDto;
import com.angelopicc.caffeinetracker.services.LoginService;
import com.angelopicc.caffeinetracker.services.UserService;

@RestController
@RequestMapping("/api/user")
public class UserRestController {
    
    private UserService userService;
    private LoginService loginService;

    public UserRestController(UserService userService, LoginService loginService) {
        this.userService = userService;
        this.loginService = loginService;
    }

    @PostMapping("/signup")
    public ResponseEntity<UserDto> register(@Valid @RequestBody RegisterDto register) {
        ResponseEntity<UserDto> entity = new ResponseEntity<>(userService.register(register), HttpStatus.CREATED);
        return entity;
    }

    @PostMapping("/login")
    public ResponseEntity<UserDto> login(@RequestBody LoginDto loginDetails) {

        return loginService.login(loginDetails);
    }

    @PostMapping("/reset/{email}")
    public void resetPassword(@PathVariable(name = "email") String email) {
        
    }

    @GetMapping
    public ResponseEntity<Set<UserDto>> getAllUsers() {

        return new ResponseEntity<>(userService.getAllUsers(), HttpStatus.OK);
    }

    @GetMapping("/username/{username}")
    public ResponseEntity<UserDto> getUserByUserName(@PathVariable(name = "username") String username) {

        return new ResponseEntity<>(userService.getUserByUserName(username), HttpStatus.OK);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<UserDto> getUserByEmail(@PathVariable(name = "email") String email) {

        return new ResponseEntity<>(userService.getUserByEmail(email), HttpStatus.OK);
    }

    @PutMapping("/{userId}")
    public ResponseEntity<UserDto> updateUser(@RequestBody UserDto user, @PathVariable(name = "userId") long userId) {

        return new ResponseEntity<>(userService.updateUser(user, userId), HttpStatus.OK);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteUser(@RequestBody ConfirmDeleteDto userDetails, @PathVariable(name = "userId") long userId) {
        // use UserDto to do a match between User retreived by ID and user sent over.
        return new ResponseEntity<>(userService.deleteUser(userDetails, userId), HttpStatus.OK);

    }
}
