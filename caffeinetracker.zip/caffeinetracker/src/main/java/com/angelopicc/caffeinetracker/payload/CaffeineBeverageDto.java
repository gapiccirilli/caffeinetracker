package com.angelopicc.caffeinetracker.payload;

public class CaffeineBeverageDto {
    
}
