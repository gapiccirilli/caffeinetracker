package com.angelopicc.caffeinetracker.controllers.rest;

import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.angelopicc.caffeinetracker.payload.CaffeineBeverageDto;

@RestController
@RequestMapping("/api/fixed")
public class FixedCaffeineBeverageRestController {
    
    @GetMapping
    public ResponseEntity<Set<CaffeineBeverageDto>> getAllBeverages() {
        return null;
    }
}
