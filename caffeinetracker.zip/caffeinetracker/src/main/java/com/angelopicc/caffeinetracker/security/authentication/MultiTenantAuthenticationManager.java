package com.angelopicc.caffeinetracker.security.authentication;

import java.util.UUID;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.angelopicc.caffeinetracker.entities.Security.CustomUserDetails;
import com.angelopicc.caffeinetracker.entities.Security.User;

@Component
public class MultiTenantAuthenticationManager {
    
    public boolean tenantIdMatches(Authentication authentication, UUID tenantId) {

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        CustomUserDetails customDetails = (CustomUserDetails) userDetails;
        User authenticatedUser = customDetails.getUser();
        System.out.println("Authenticated User's Tenant Id: \"" + authenticatedUser.getTenantId() + "\"");
        System.out.println("Current User's Tenant Id: \"" + tenantId + "\"");

        return authenticatedUser.getTenantId().equals(tenantId);
    }
}
