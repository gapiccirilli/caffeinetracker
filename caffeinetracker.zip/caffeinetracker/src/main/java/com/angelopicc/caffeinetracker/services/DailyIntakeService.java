package com.angelopicc.caffeinetracker.services;

import java.time.LocalDate;
import java.util.Set;

import com.angelopicc.caffeinetracker.entities.Caffeine;
import com.angelopicc.caffeinetracker.entities.DailyIntake;
import com.angelopicc.caffeinetracker.exceptions.IntakeNotFoundException;
import com.angelopicc.caffeinetracker.payload.DailyIntakeDto;

public interface DailyIntakeService {

    DailyIntakeDto getDailyIntake(String tenantId, LocalDate date);

    Set<DailyIntakeDto> getAllIntakes(String tenantId, LocalDate startDate, LocalDate endDate);

    DailyIntake updateDailyIntake(String tenantId, Caffeine caffeine);

    void refreshCaffeineAmount(String tenantId, long caffeineId, LocalDate date);
}
