package com.angelopicc.caffeinetracker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.angelopicc.caffeinetracker.entities.CustomCaffeineBeverage;

@Repository
public interface CustomCaffeineBeverageRepository extends JpaRepository<CustomCaffeineBeverage, Long>{
    
}
