package com.angelopicc.caffeinetracker.security.filter;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.angelopicc.caffeinetracker.entities.Security.CustomUserDetails;
import com.angelopicc.caffeinetracker.entities.Security.User;
import com.angelopicc.caffeinetracker.exceptions.UserForgeryException;
import com.angelopicc.caffeinetracker.repository.UserRepository;
import com.angelopicc.caffeinetracker.utility.constant.SecurityConstants;

@Component
public class TenantIdValidator {
    
    private UserRepository userRepository;

    public TenantIdValidator(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void tenantIdIsValid(String tenantId) throws UserForgeryException {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = userRepository.findByUserName(username);
        String authenticatedTenantId = user.getTenantId();

        if (!authenticatedTenantId.equals(tenantId)) {
            throw new UserForgeryException(SecurityConstants.USER_FORGERY);
        }
    }
}
