package com.angelopicc.caffeinetracker.exceptions.handlers;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.angelopicc.caffeinetracker.exceptions.EmailAlreadyExists;
import com.angelopicc.caffeinetracker.exceptions.EmailNotFoundException;
import com.angelopicc.caffeinetracker.exceptions.IntakeNotFoundException;
import com.angelopicc.caffeinetracker.exceptions.UserForgeryException;
import com.angelopicc.caffeinetracker.exceptions.UserNameAlreadyExists;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    
    @ExceptionHandler(EmailAlreadyExists.class)
    public ResponseEntity<Error> handleEmailAlreadyExistsException(EmailAlreadyExists exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));

        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EmailNotFoundException.class)
    public ResponseEntity<Error> handleEmailNotFoundException(EmailNotFoundException exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));
        
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(IntakeNotFoundException.class)
    public ResponseEntity<Error> handleIntakeNotFoundException(IntakeNotFoundException exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));
        
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UserForgeryException.class)
    public ResponseEntity<Error> handleUserForgeryException(UserForgeryException exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));
        
        return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(UserNameAlreadyExists.class)
    public ResponseEntity<Error> handleUserNameAlreadyExists(UserNameAlreadyExists exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));
        
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, 
    HttpStatus status, WebRequest request) {

        BindingResult bindingResult = ex.getBindingResult();
        FieldError fieldError = bindingResult.getFieldError();
        String message = fieldError.getDefaultMessage();

        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), message, 
        request.getDescription(false));
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Error> handleGlobalException(Exception exception, WebRequest request) {
        Error error = new Error(LocalDateTime.of(LocalDate.now(), LocalTime.now()), exception.getMessage(), 
        request.getDescription(false));
        
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
