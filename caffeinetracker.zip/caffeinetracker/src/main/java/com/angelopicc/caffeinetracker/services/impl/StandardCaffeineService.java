package com.angelopicc.caffeinetracker.services.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.angelopicc.caffeinetracker.entities.Caffeine;
import com.angelopicc.caffeinetracker.entities.DailyIntake;
import com.angelopicc.caffeinetracker.exceptions.IntakeNotFoundException;
import com.angelopicc.caffeinetracker.payload.CaffeineDto;
import com.angelopicc.caffeinetracker.repository.CaffeineRepository;
import com.angelopicc.caffeinetracker.repository.DailyIntakeRepository;
import com.angelopicc.caffeinetracker.services.CaffeineService;
import com.angelopicc.caffeinetracker.services.DailyIntakeService;


@Service
public class StandardCaffeineService implements CaffeineService {

    private DailyIntakeRepository dailyIntakeRepository;

    private CaffeineRepository caffeineRepository;

    private DailyIntakeService dailyIntakeService;

    public StandardCaffeineService(DailyIntakeRepository dailyIntakeRepository, CaffeineRepository caffeineRepository,
    DailyIntakeService dailyIntakeService) {
        this.dailyIntakeRepository = dailyIntakeRepository;
        this.caffeineRepository = caffeineRepository;
        this.dailyIntakeService = dailyIntakeService;
    }

    @Override
    public CaffeineDto createCaffeine(String tenantId, CaffeineDto caffeine) {

        Caffeine caffeineEntity = mapToEntity(caffeine);
        LocalDate caffeineDate = LocalDate.of(caffeine.getYear(), caffeine.getMonth(), caffeine.getDay());

        if (isFirstCaffeine(tenantId, caffeineDate)) {
            
            DailyIntake intake = new DailyIntake();
            intake.setCaffeineContent(caffeine.getAmount());
            intake.setDate(caffeineDate);
            intake.setTenantId(tenantId);
            dailyIntakeRepository.save(intake);
            
            caffeineEntity.setDailyIntake(intake);
            caffeineEntity.setTenantId(tenantId);
            Caffeine returnedCaffeine = caffeineRepository.save(caffeineEntity);

            return mapToDto(returnedCaffeine);
        }
        else {
            
            // DailyIntake intake = dailyIntakeRepository.findByDate(caffeineDate);
            DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(caffeineDate, tenantId);
            caffeineEntity.setDailyIntake(intake);
            caffeineEntity.setTenantId(tenantId);
            Caffeine returnedCaffeine = caffeineRepository.save(caffeineEntity);

            intake = dailyIntakeService.updateDailyIntake(tenantId, returnedCaffeine);
            dailyIntakeRepository.save(intake);

            return mapToDto(returnedCaffeine);
        }

    }

    @Override
    public Set<CaffeineDto> getAllCaffeine(String tenantId, LocalDate date) throws IntakeNotFoundException {
        
        // DailyIntake intake = dailyIntakeRepository.findByDate(date);
        DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(date, tenantId);

        if (intake == null)
            throw new IntakeNotFoundException(date);
        
        return mapToSetOfCaffeine(intake.getCaffeine());
    }

    @Override
    public CaffeineDto getCaffeineById(String tenantId, long caffeineId) {

        // Caffeine caffeine = caffeineRepository.getReferenceById(caffeineId);
        Caffeine caffeine = caffeineRepository.findByIdAndTenantId(caffeineId, tenantId);
        return mapToDto(caffeine);
    }

    @Override
    public CaffeineDto updateCaffeine(String tenantId, CaffeineDto caffeine, long caffeineId) {

        // Caffeine originalCaffeine = caffeineRepository.getReferenceById(caffeineId);
        Caffeine originalCaffeine = caffeineRepository.findByIdAndTenantId(caffeineId, tenantId);
        originalCaffeine.setBeverage(caffeine.getBeverage());
        originalCaffeine.setAmount(caffeine.getAmount());
        Caffeine updatedCaffeine = caffeineRepository.save(originalCaffeine);

        DailyIntake intake = updatedCaffeine.getDailyIntake();

        int totalCaffeine = 0;

            for (Caffeine caf : intake.getCaffeine()) {
                totalCaffeine += caf.getAmount();
            }
        intake.setCaffeineContent(totalCaffeine);
        dailyIntakeRepository.save(intake);

        return mapToDto(updatedCaffeine);
    }

    @Override
    public void deleteCaffeine(String tenantId, long caffeineId, LocalDate date) {

        // caffeineRepository.deleteByIdAndTenantId(caffeineId, tenantId);
        caffeineRepository.deleteById(caffeineId);
        // DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(date, tenantId);
        // intake.setCaffeine(caffeineSet);
        dailyIntakeService.refreshCaffeineAmount(tenantId, caffeineId, date);
        // dailyIntakeRepository.save(intake);

    }

    private boolean isFirstCaffeine(String tenantId, LocalDate date) {
        // used to see if the caffeine object added is the first of the day. The date object is used to quiry the database for an intake
        // object by date. If the date throws an exception, then it can be handled by return true. If an intake object is returned (found),
        // then return false and add caffeine to current intake. The LocalDateTime object passed in is from the caffeine object.

        // DailyIntake intake = dailyIntakeRepository.findByDate(date);
        DailyIntake intake = dailyIntakeRepository.findByDateAndTenantId(date, tenantId);

        if (intake == null) 
            return true;
        else
            return false;
        
    }

    private Caffeine mapToEntity(CaffeineDto dto) {

        Caffeine caffeine = new Caffeine();
        caffeine.setBeverage(dto.getBeverage());
        caffeine.setId(dto.getId());
        caffeine.setAmount(dto.getAmount());
        caffeine.setDate(LocalDateTime.of(dto.getYear(), dto.getMonth(), dto.getDay(), 
        dto.getHour(), dto.getMinute(), dto.getSeconds()));
        
        return caffeine;
    }

    private CaffeineDto mapToDto(Caffeine caffeine) {
        CaffeineDto dto = new CaffeineDto();

        dto.setId(caffeine.getId());
        dto.setBeverage(caffeine.getBeverage());
        dto.setAmount(caffeine.getAmount());
        dto.setYear(caffeine.getDate().getYear());
        dto.setMonth(caffeine.getDate().getMonthValue());
        dto.setDay(caffeine.getDate().getDayOfMonth());
        dto.setHour(caffeine.getDate().getHour());
        dto.setMinute(caffeine.getDate().getMinute());
        dto.setSeconds(caffeine.getDate().getSecond());

        return dto;
    }

    private Set<CaffeineDto> mapToSetOfCaffeine(Set<Caffeine> caffeine) {

        Set<CaffeineDto> dtos = new HashSet<>();
        Object[] caffeineArray = caffeine.toArray();

        for (int x = 0; x < caffeine.size(); ++x) {
            Caffeine caf = (Caffeine)caffeineArray[x];

            CaffeineDto dto = new CaffeineDto(caf.getId(), caf.getBeverage(), caf.getDate().getMonthValue(), 
            caf.getDate().getDayOfMonth(), caf.getDate().getYear(), caf.getDate().getHour(), 
            caf.getDate().getMinute(), caf.getDate().getSecond(), caf.getAmount());

            dtos.add(dto);
        }
        return dtos;
    }
    
}
