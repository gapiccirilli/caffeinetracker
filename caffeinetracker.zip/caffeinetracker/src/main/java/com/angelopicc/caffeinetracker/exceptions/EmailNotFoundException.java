package com.angelopicc.caffeinetracker.exceptions;

public class EmailNotFoundException extends Exception {
    
    public EmailNotFoundException(String email) {
        super("The email " + "\"" + email + "\" is not found in our records");
    }
}
