package com.angelopicc.caffeinetracker.services.impl;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.angelopicc.caffeinetracker.entities.Security.CustomUserDetails;
import com.angelopicc.caffeinetracker.entities.Security.User;
import com.angelopicc.caffeinetracker.exceptions.EmailAlreadyExists;
import com.angelopicc.caffeinetracker.exceptions.UserNameAlreadyExists;
import com.angelopicc.caffeinetracker.payload.ConfirmDeleteDto;
import com.angelopicc.caffeinetracker.payload.RegisterDto;
import com.angelopicc.caffeinetracker.payload.UserDto;
import com.angelopicc.caffeinetracker.repository.UserRepository;
import com.angelopicc.caffeinetracker.security.authorization.Role;
import com.angelopicc.caffeinetracker.services.UserService;

@Service
@Transactional
public class CustomUserService implements UserService, UserDetailsService {

    private UserRepository userRepository;

    public CustomUserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUserName(username);
        if (user == null) {
            throw new UsernameNotFoundException("The username " + "\"" + username + "\" is not found in our records");
        }
        CustomUserDetails userDetails = new CustomUserDetails(user);
        return userDetails;
    }
    // handle exception 
    @Override
    public UserDto register(RegisterDto user) {
        User returnedUser;
        
        checkForExistingUser(user.getUserName(), user.getEmail());
        returnedUser = userRepository.save(mapRegisterToEntity(user));

        return mapToDto(returnedUser);
    }

    @Override
    public Set<UserDto> getAllUsers() {

        List<User> userList = userRepository.findAll();
        Set<UserDto> users = convertUserListToUserDtoSet(userList);
        return users;
    }

    @Override
    public UserDto getUserByUserName(String username) {
        // for future use
        return null;
    }

    @Override
    public UserDto getUserByEmail(String email) {
        // for future use
        return null;
    }

    @Override
    public UserDto updateUser(UserDto user, long userId) {
        // add a check for username or email
        User foundUser = userRepository.getReferenceById(userId);
        foundUser.setFirstName(user.getFirstName());
        foundUser.setLastName(user.getLastName());
        foundUser.setEmail(user.getEmail());
        foundUser.setUserName(user.getUserName());
        User updatedUser = userRepository.save(foundUser);
        return mapToDto(updatedUser);
    }

    @Override
    public String deleteUser(ConfirmDeleteDto userDetails, long userId) {
        User user = userRepository.getReferenceById(userId);
        boolean isValid = validateUserForDelete(userDetails, user);

        if (isValid) {
            userRepository.delete(user);
            return "User \"" + user.getUserName() + "\" has successfully been deleted";
        }

        return "Username and password combination is incorrect";
    }

    private void checkForExistingUser(String userName, String email) throws UserNameAlreadyExists, EmailAlreadyExists {
        User userByUserName = userRepository.findByUserName(userName);
        User userByEmail = userRepository.findByEmail(email);
        
        if (userByUserName != null) {
            throw new UserNameAlreadyExists(userName);
        }
        if (userByEmail != null) {
            throw new EmailAlreadyExists(email);
        }
    }

    private boolean validateUserForDelete(ConfirmDeleteDto rawCredentials, User actualDetails) {

        PasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(rawCredentials.getPassword());

        if (encodedPassword.equalsIgnoreCase(actualDetails.getPassword()) && 
        rawCredentials.getEmail().equalsIgnoreCase(actualDetails.getEmail())) {
            return true;
        }

        return false;
    }

    private UserDto mapToDto(User user) {
        UserDto dto = new UserDto(user.getId(), user.getTenantId(), user.getFirstName(), user.getLastName(), user.getUserName(), user.getEmail());
        return dto;
    }

    private User mapToEntity(UserDto dto) {
        User user = new User();
        user.setId(dto.getId());
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setUserName(dto.getUserName());
        user.setEmail(dto.getEmail());
        return user;
    }

    private User mapRegisterToEntity(RegisterDto dto) {
        User user = new User();
        String encodedPassword = encodePassword(dto.getPassword());
        String tenantId = UUID.randomUUID().toString();

        user.setTenantId(tenantId);
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setUserName(dto.getUserName());
        user.setEmail(dto.getEmail());
        user.setPassword(encodedPassword);
        user.setJoinedDate(LocalDate.now());
        user.setLastLogin(LocalDate.now());
        user.setRole(Role.ROLE_ADMIN.name());
        user.setAuthorities(Role.ROLE_ADMIN.getAuthorities());

        return user;
    }

    private Set<UserDto> convertUserListToUserDtoSet(List<User> userList) {
        Set<UserDto> users = new HashSet<>();

        for (User user : userList) {
            UserDto dto = new UserDto(user.getId(), user.getTenantId(), user.getFirstName(), 
            user.getLastName(), user.getUserName(), user.getEmail());

            users.add(dto);
        }
        return users;
    }

    private String encodePassword(String password) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }
    
}
