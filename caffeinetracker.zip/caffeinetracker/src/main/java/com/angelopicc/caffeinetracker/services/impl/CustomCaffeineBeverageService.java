package com.angelopicc.caffeinetracker.services.impl;


import org.springframework.stereotype.Service;

import com.angelopicc.caffeinetracker.payload.BeverageResponse;
import com.angelopicc.caffeinetracker.payload.CaffeineBeverageDto;
import com.angelopicc.caffeinetracker.services.CaffeineBeverageService;

@Service
public class CustomCaffeineBeverageService implements CaffeineBeverageService {

    @Override
    public CaffeineBeverageDto createBeverage(CaffeineBeverageDto caffeineBeverage) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public BeverageResponse getAllBeverages() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public CaffeineBeverageDto updateBeverage(CaffeineBeverageDto caffeineBeverage, long beverageId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String deleteBeverage(long beverageId) {
        // TODO Auto-generated method stub
        return null;
    }
    
}
