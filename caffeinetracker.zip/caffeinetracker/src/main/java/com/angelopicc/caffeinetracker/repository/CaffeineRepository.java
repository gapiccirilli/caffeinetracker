package com.angelopicc.caffeinetracker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.angelopicc.caffeinetracker.entities.Caffeine;

@Repository
public interface CaffeineRepository extends JpaRepository<Caffeine, Long> {
    
    Caffeine findByIdAndTenantId(long caffeineId, String tenantId);

    void deleteByIdAndTenantId(long caffeineId, String tenantId);
}
