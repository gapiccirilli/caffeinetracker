package com.angelopicc.caffeinetracker.services;

public interface PasswordService {
    
    void resetPassword(String email);

    void forgotPassword(String email);
}
