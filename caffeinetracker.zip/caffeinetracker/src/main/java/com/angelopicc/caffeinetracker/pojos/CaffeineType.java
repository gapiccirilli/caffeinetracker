package com.angelopicc.caffeinetracker.pojos;

public enum CaffeineType {
    SOFT_DRINK,
    COFFEE,
    TEA,
    ENERGY_DRINK,
    OTHER;
}
