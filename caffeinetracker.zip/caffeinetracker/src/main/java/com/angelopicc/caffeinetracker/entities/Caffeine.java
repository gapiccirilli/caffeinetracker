package com.angelopicc.caffeinetracker.entities;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "caffeine")
public class Caffeine {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String tenantId;

    private String beverage;

    private LocalDateTime date;

    private int amount;

    @ManyToOne
    @JoinColumn(name = "daily_intake_id")
    private DailyIntake dailyIntake;

    public Caffeine(long id, String tenantId, String beverage, LocalDateTime date, int amount,
            DailyIntake dailyIntake) {
        this.id = id;
        this.tenantId = tenantId;
        this.beverage = beverage;
        this.date = date;
        this.amount = amount;
        this.dailyIntake = dailyIntake;
    }

    public Caffeine() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBeverage() {
        return beverage;
    }

    public void setBeverage(String beverage) {
        this.beverage = beverage;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public DailyIntake getDailyIntake() {
        return dailyIntake;
    }

    public void setDailyIntake(DailyIntake dailyIntake) {
        this.dailyIntake = dailyIntake;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    @Override
    public String toString() {
        return "Caffeine [id=" + id + ", tenantId=" + tenantId + ", beverage=" + beverage + ", date=" + date
                + ", amount=" + amount + ", dailyIntake=" + dailyIntake + "]";
    }
}
