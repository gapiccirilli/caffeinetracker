package com.angelopicc.caffeinetracker.services;

import java.time.LocalDate;
import java.util.Set;

import com.angelopicc.caffeinetracker.payload.CaffeineDto;

public interface CaffeineService {
    
    CaffeineDto createCaffeine(String tenantId, CaffeineDto caffeine);

    Set<CaffeineDto> getAllCaffeine(String tenantId, LocalDate date);

    CaffeineDto getCaffeineById(String tenantId, long caffeineId);

    CaffeineDto updateCaffeine(String tenantId, CaffeineDto caffeine, long caffeineId);

    void deleteCaffeine(String tenantId, long caffeineId, LocalDate date);
}
