package com.angelopicc.caffeinetracker.exceptions;

public class UserNameAlreadyExists extends RuntimeException {

    public UserNameAlreadyExists(String username) {
        super("The username " + "\"" + username + "\" aleady exists in our records");
    }
}
