package com.angelopicc.caffeinetracker.exceptions;

import java.time.LocalDate;

public class IntakeNotFoundException extends RuntimeException {
    
    private LocalDate date;

    public IntakeNotFoundException(LocalDate date) {
        super("No caffeine submissions");
        this.date = date;
    }

    public LocalDate getDate() {
        return date;
    }
}
