package com.angelopicc.caffeinetracker.controllers.rest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.angelopicc.caffeinetracker.payload.BeverageResponse;
import com.angelopicc.caffeinetracker.payload.CaffeineBeverageDto;

@RestController
@RequestMapping("/api/custom")
public class CustomCaffeineBeverageRestController {
    
    @PostMapping
    public ResponseEntity<CaffeineBeverageDto> createBeverage(@RequestBody CaffeineBeverageDto beverage) {
        return null;
    }

    @GetMapping
    public ResponseEntity<BeverageResponse> getAllBeverages() {
        return null;
    }

    @PutMapping("/{beverageId}")
    public ResponseEntity<CaffeineBeverageDto> updateBeverage(@RequestBody CaffeineBeverageDto beverage, 
    @PathVariable(name = "beverageId") long beverageId) {

        return null;
    }

    @DeleteMapping("/{beverageId}")
    public ResponseEntity<String> deleteBeverage(@PathVariable(name = "beverageId") long beverageId) {
        return null;
    }
}
