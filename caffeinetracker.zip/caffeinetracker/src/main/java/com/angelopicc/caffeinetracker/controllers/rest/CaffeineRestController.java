package com.angelopicc.caffeinetracker.controllers.rest;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.angelopicc.caffeinetracker.payload.CaffeineDto;
import com.angelopicc.caffeinetracker.security.filter.TenantIdValidator;
import com.angelopicc.caffeinetracker.services.CaffeineService;

@RestController
@RequestMapping("/api")
public class CaffeineRestController {

    private CaffeineService standardCaffeineService;

    private TenantIdValidator tenantIdValidator;

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public CaffeineRestController(CaffeineService standardCaffeineService, TenantIdValidator tenantIdValidator) {
        this.standardCaffeineService = standardCaffeineService;
        this.tenantIdValidator = tenantIdValidator;
    }

    @PostMapping("/{tenantId}/intake/caffeine")
    public ResponseEntity<CaffeineDto> createCaffeine(@PathVariable String tenantId, @Valid @RequestBody CaffeineDto caffeine) {

        tenantIdValidator.tenantIdIsValid(tenantId);

        CaffeineDto dto = standardCaffeineService.createCaffeine(tenantId, caffeine);

        if (dto.isNull()) {
            return new ResponseEntity<>(dto, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    @GetMapping("/{tenantId}/intake/caffeine")
    public ResponseEntity<Set<CaffeineDto>> getAllCaffeine(@PathVariable String tenantId, @RequestParam String date) {

        tenantIdValidator.tenantIdIsValid(tenantId);

        return new ResponseEntity<>(standardCaffeineService.getAllCaffeine(tenantId, LocalDate.parse(date, formatter)), HttpStatus.OK);
        
    }

    @GetMapping("/{tenantId}/intake/caffeine/{caffeineId}")
    public ResponseEntity<CaffeineDto> getCaffeineById(@PathVariable String tenantId, 
    @PathVariable(name = "caffeineId") long caffeineId) {

        tenantIdValidator.tenantIdIsValid(tenantId);
        
        return new ResponseEntity<>(standardCaffeineService.getCaffeineById(tenantId, caffeineId), HttpStatus.OK);
    }

    @PutMapping("/{tenantId}/intake/caffeine/{caffeineId}")
    public ResponseEntity<CaffeineDto> updateCaffeine(@PathVariable String tenantId, @Valid @RequestBody CaffeineDto caffeine, 
    @PathVariable(name = "caffeineId") long caffeineId) {

        tenantIdValidator.tenantIdIsValid(tenantId);

        return new ResponseEntity<>(standardCaffeineService.updateCaffeine(tenantId, caffeine, caffeineId), HttpStatus.OK);
    }

    @DeleteMapping("/{tenantId}/intake/caffeine/{caffeineId}")
    public ResponseEntity<String> deleteCaffeine(@PathVariable String tenantId, 
    @PathVariable(name = "caffeineId") long caffeineId, @RequestParam String date) {
        
        tenantIdValidator.tenantIdIsValid(tenantId);

        standardCaffeineService.deleteCaffeine(tenantId, caffeineId, LocalDate.parse(date, formatter));
        return new ResponseEntity<>("Successfully Deleted!", HttpStatus.OK);
    }
}