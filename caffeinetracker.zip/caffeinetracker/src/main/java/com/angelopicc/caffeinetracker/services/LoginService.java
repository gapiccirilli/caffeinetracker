package com.angelopicc.caffeinetracker.services;

import org.springframework.http.ResponseEntity;

import com.angelopicc.caffeinetracker.payload.LoginDto;
import com.angelopicc.caffeinetracker.payload.UserDto;

public interface LoginService {
    
    ResponseEntity<UserDto> login(LoginDto loginDetails);
}
