package com.angelopicc.caffeinetracker.exceptions;

public class UserForgeryException extends RuntimeException {

    public UserForgeryException(String message) {
        super(message);
    }
}
