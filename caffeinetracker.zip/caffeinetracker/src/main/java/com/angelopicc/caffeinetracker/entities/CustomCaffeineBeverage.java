package com.angelopicc.caffeinetracker.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.angelopicc.caffeinetracker.pojos.CaffeineType;

@Entity
@Table(name = "custom_caffeine_beverage")
public class CustomCaffeineBeverage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private long id;

   private CaffeineType type;

   private String name;

   private byte size;

    private int caffeineContent;

    public CustomCaffeineBeverage(long id, CaffeineType type, String name, byte size, int caffeineContent) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.size = size;
        this.caffeineContent = caffeineContent;
    }

    public CustomCaffeineBeverage() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public CaffeineType getType() {
        return type;
    }

    public void setType(CaffeineType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte getSize() {
        return size;
    }

    public void setSize(byte size) {
        this.size = size;
    }

    public int getCaffeineContent() {
        return caffeineContent;
    }

    public void setCaffeineContent(int caffeineContent) {
        this.caffeineContent = caffeineContent;
    }
}
