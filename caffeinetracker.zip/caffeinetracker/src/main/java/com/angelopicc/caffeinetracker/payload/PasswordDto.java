package com.angelopicc.caffeinetracker.payload;

public class PasswordDto {
    
    private String password;

    public PasswordDto(String password) {
        this.password = password;
    }

    public PasswordDto() {
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
