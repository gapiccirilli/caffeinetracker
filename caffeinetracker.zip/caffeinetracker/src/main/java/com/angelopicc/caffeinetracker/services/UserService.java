package com.angelopicc.caffeinetracker.services;

import java.util.Set;

import com.angelopicc.caffeinetracker.payload.ConfirmDeleteDto;
import com.angelopicc.caffeinetracker.payload.RegisterDto;
import com.angelopicc.caffeinetracker.payload.UserDto;

public interface UserService {
    
    UserDto register(RegisterDto user);

    Set<UserDto> getAllUsers();

    UserDto getUserByUserName(String username);

    UserDto getUserByEmail(String email);

    UserDto updateUser(UserDto user, long userId);

    String deleteUser(ConfirmDeleteDto userDetails, long userId);
}
