package com.angelopicc.caffeinetracker.utility.constant;

public class SecurityConstants {
    public static final long EXPIRATION_TIME = 604_800_000; // 7 days
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String JWT_TOKEN_HEADER = "Jwt-Token"; //custom header
    public static final String TOKEN_CANNOT_BE_VERIFIED = "Token cannot be verified";
    public static final String TOKEN_ISSUER = "Caffeine Tracker App";
    public static final String AUTHORITIES = "authorities";
    public static final String FORBIDDEN_MESSAGE = "You must login";
    public static final String ACCESS_DENIED_MESSAGE = "You do not have permission to access this resource";
    public static final String OPTIONS_HTTP_METHOD = "OPTIONS";
    public static final String[] PUBLIC_URLS = {"/api/user/login", "/api/user/signup", "/api/user/reset/**"};
    public static final String DELETE_SUCCESSFUL = "Successfully Deleted!";
    public static final String DELETE_FAILURE = "Something went wrong.";
    public static final String USER_FORGERY = "This is not a valid ID for this user";
}
