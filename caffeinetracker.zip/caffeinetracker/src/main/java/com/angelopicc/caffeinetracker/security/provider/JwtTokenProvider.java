package com.angelopicc.caffeinetracker.security.provider;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;

import com.angelopicc.caffeinetracker.utility.constant.SecurityConstants;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.JWTVerifier;

@Component
public class JwtTokenProvider {
    @Value("${jwt.secret}")
    private String secret;

    public String generateJwtToken(UserDetails userDetails) {
        String[] claims = getClaims(userDetails); // claims are the authorities or permissions
        Instant expirationInstant = Instant.now();
        return JWT.create()
        .withIssuer(SecurityConstants.TOKEN_ISSUER)
        .withAudience(SecurityConstants.TOKEN_ISSUER)
        .withIssuedAt(Instant.now())
        .withSubject(userDetails.getUsername())
        .withArrayClaim(SecurityConstants.AUTHORITIES, claims)
        .withExpiresAt(expirationInstant.plusMillis(SecurityConstants.EXPIRATION_TIME))
        .sign(Algorithm.HMAC512(secret));
    }

    public List<GrantedAuthority> getAuthorities(String token) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        String[] claims = getClaimsFromToken(token);
        for (String claim : claims) {
            authorities.add(new SimpleGrantedAuthority(claim));
        }
        return authorities;
    }

    // this method is telling spring security context that this user is authenticated
    public Authentication getAuthentication(String username, List<GrantedAuthority> authorities, HttpServletRequest request) {
        UsernamePasswordAuthenticationToken userAuthToken = 
        new UsernamePasswordAuthenticationToken(username, null, authorities);
        userAuthToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        return userAuthToken;
    }

    public boolean isTokenValid(String username, String token) {
        JWTVerifier verifier = getJWTVerifier();
        return StringUtils.isNotEmpty(username) && !isTokenExpired(verifier, token);
    }

    public String getSubject(String token) {
        JWTVerifier verifier = getJWTVerifier();
        return verifier.verify(token).getSubject();
    }

    private boolean isTokenExpired(JWTVerifier verifier, String token) {
        Instant expiration = verifier.verify(token).getExpiresAtAsInstant();
        return expiration.isBefore(Instant.now());
    }

    private String[] getClaimsFromToken(String token) {
        JWTVerifier verifier = getJWTVerifier();
        return verifier.verify(token).getClaim(SecurityConstants.AUTHORITIES).asArray(String.class);
    }

    private JWTVerifier getJWTVerifier() {
        JWTVerifier verifier;

        try {
            Algorithm algo = Algorithm.HMAC512(secret);
            verifier = JWT.require(algo).withIssuer(SecurityConstants.TOKEN_ISSUER).build();
        } catch(Exception e) {
            throw new JWTVerificationException(SecurityConstants.TOKEN_CANNOT_BE_VERIFIED);
        }
        return verifier;
    }

    private String[] getClaims(UserDetails userDetails) {

        Object[] objClaims = userDetails.getAuthorities().toArray();
        String[] claims = new String[objClaims.length];
        int x = 0;

        for (GrantedAuthority claim : userDetails.getAuthorities()) {
            claims[x] = claim.getAuthority();
            ++x;
        }

        return claims;
    }
}
