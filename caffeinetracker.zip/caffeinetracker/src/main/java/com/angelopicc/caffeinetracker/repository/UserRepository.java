package com.angelopicc.caffeinetracker.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.angelopicc.caffeinetracker.entities.Security.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{
    
    User findByUserName(String username);

    User findByEmail(String email);
}
