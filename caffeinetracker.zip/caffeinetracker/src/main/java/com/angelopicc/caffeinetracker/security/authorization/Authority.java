package com.angelopicc.caffeinetracker.security.authorization;

public class Authority {
    public static final String[] USER_AUTHORITIES = {"READ"};
    public static final String[] ADMIN_AUTHORITIES = {"READ", "WRITE", "UPDATE", "DELETE"};
}
