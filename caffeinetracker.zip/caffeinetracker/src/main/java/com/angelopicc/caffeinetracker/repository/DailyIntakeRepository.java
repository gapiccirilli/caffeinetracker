package com.angelopicc.caffeinetracker.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.angelopicc.caffeinetracker.entities.DailyIntake;

@Repository
public interface DailyIntakeRepository extends JpaRepository<DailyIntake, Long> {

    DailyIntake findByDate(LocalDate date);

    DailyIntake findByDateAndTenantId(LocalDate date, String tenantId);
    
    List<DailyIntake> findByDateBetween(LocalDate startDate, LocalDate endDate);

    List<DailyIntake> findByTenantIdAndDateBetween(String tenantId, LocalDate startDate, LocalDate endDate);
}
