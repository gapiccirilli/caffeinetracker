package com.angelopicc.caffeinetracker.services.impl;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import com.angelopicc.caffeinetracker.entities.Security.CustomUserDetails;
import com.angelopicc.caffeinetracker.entities.Security.User;
import com.angelopicc.caffeinetracker.payload.LoginDto;
import com.angelopicc.caffeinetracker.payload.UserDto;
import com.angelopicc.caffeinetracker.repository.UserRepository;
import com.angelopicc.caffeinetracker.security.provider.JwtTokenProvider;
import com.angelopicc.caffeinetracker.services.LoginService;
import com.angelopicc.caffeinetracker.utility.constant.SecurityConstants;

@Service
public class StandardLoginService implements LoginService {

    private UserRepository userRepository;
    private AuthenticationManager authenticationManager;
    private JwtTokenProvider jwtTokenProvider;

    public StandardLoginService(UserRepository userRepository, AuthenticationManager authenticationManager,
            JwtTokenProvider jwtTokenProvider) {
        this.userRepository = userRepository;
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    public ResponseEntity<UserDto> login(LoginDto loginDetails) {
        authenticate(loginDetails.getUserName(), loginDetails.getPassword());
        User loginUser = userRepository.findByUserName(loginDetails.getUserName());
        CustomUserDetails userDetails = new CustomUserDetails(loginUser);
        HttpHeaders jwtHeader = getJwtHeader(userDetails);
        return new ResponseEntity<>(mapToDto(loginUser), jwtHeader, HttpStatus.OK);
    }

    private void authenticate(String userName, String password) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userName, password));
    }

    private HttpHeaders getJwtHeader(CustomUserDetails userDetails) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(SecurityConstants.JWT_TOKEN_HEADER, jwtTokenProvider.generateJwtToken(userDetails));
        return headers;
    }
    
    private UserDto mapToDto(User user) {
        UserDto dto = new UserDto(user.getId(), user.getTenantId(), user.getFirstName(), user.getLastName(), user.getUserName(), user.getEmail());
        return dto;
    }
}
