package com.angelopicc.caffeinetracker.payload;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CaffeineDto {
    
    private long id;

    @NotEmpty
    private String beverage;

    @NotNull
    private int amount;

    private int month;

    private int day;

    private int year;

    private int hour;

    private int minute;

    private int seconds;


    public CaffeineDto(long id, String beverage, int month, int day, int year, int hour, int minute,
            int seconds, int amount) {
        this.id = id;
        this.beverage = beverage;
        this.month = month;
        this.day = day;
        this.year = year;
        this.hour = hour;
        this.minute = minute;
        this.seconds = seconds;
        this.amount = amount;
    }

    public CaffeineDto() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBeverage() {
        return beverage;
    }

    public void setBeverage(String beverage) {
        this.beverage = beverage;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public boolean isNull() {

        if (this.id == 0 && this.beverage == null && this.year == 0 && this.month == 0 && 
        this.day == 0 && this.hour == 0 && this.minute == 0 && this.seconds == 0 && this.amount == 0) {
            return true;
        }

        return false;
    }
    
}
