package com.angelopicc.caffeinetracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaffeinetrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaffeinetrackerApplication.class, args);
	}

}
