package com.angelopicc.caffeinetracker.services;

import com.angelopicc.caffeinetracker.payload.BeverageResponse;
import com.angelopicc.caffeinetracker.payload.CaffeineBeverageDto;

public interface CaffeineBeverageService {
    
    CaffeineBeverageDto createBeverage(CaffeineBeverageDto caffeineBeverage);

    BeverageResponse getAllBeverages();

    CaffeineBeverageDto updateBeverage(CaffeineBeverageDto caffeineBeverage, long beverageId);

    String deleteBeverage(long beverageId);
}
